/* eslint-env node */
/**
 * @type {import('electron-builder').Configuration}
 * @see https://www.electron.build/configuration/configuration
 */
module.exports = {
    appId: 'cloud.underweb.uwx',
    productName: 'UnderWeb X',
    icon: 'images/VRCX.png',
    files: [
        'build/html/**/*',
        'src-electron/*',
        'images/VRCX.png',
        'images/VRCX.ico',
        'images/VRCX_notify.png',
        'images/VRCX_notify.ico',
        'Version',
        'src-electron/libs/linux/libopenvr_api.so',
        '.no-updater'
    ],
    asarUnpack: [
        'node_modules/node-api-dotnet/**/*',
        'node_modules/node-api-dotnet/net10.0/**/*',
        'build/Electron/*',
        'build/Electron/**',
        'build/Electron/dotnet-runtime/**/*',
        'src-electron/libs/linux/libopenvr_api.so'
    ],
    extraResources: [
        {
            from: 'build/Electron/',
            to: 'app.asar.unpacked/build/Electron/'
        },
        {
            from: 'node_modules/node-api-dotnet/net10.0/Microsoft.JavaScript.NodeApi.dll',
            to: 'app.asar.unpacked/node_modules/node-api-dotnet/net10.0/Microsoft.JavaScript.NodeApi.dll'
        },
        {
            from: 'node_modules/node-api-dotnet/net10.0/Microsoft.JavaScript.NodeApi.DotNetHost.dll',
            to: 'app.asar.unpacked/node_modules/node-api-dotnet/net10.0/Microsoft.JavaScript.NodeApi.DotNetHost.dll'
        },
        {
            from: 'build/Electron/dotnet-runtime/',
            to: 'dotnet-runtime/'
        },
        {
            from: 'src-electron/libs/linux/libopenvr_api.so',
            to: 'bin/libopenvr_api.so'
        },
        {
            from: 'src-electron/libs/linux/libopenvr_api.so',
            to: 'app.asar.unpacked/build/Electron/openvr_api.so'
        }
    ],
    directories: {
        output: 'build'
    },
    linux: {
        artifactName: 'UnderWebX_Version.${ext}',
        target: ['AppImage'],
        icon: 'images/VRCX.png',
        executableName: 'UnderWebX',
        mimeTypes: ['x-scheme-handler/uwx'],
        desktop: {
            entry: {
                Name: 'UnderWeb X',
                Comment: 'UnderWeb VRChat network control client',
                Icon: 'VRCX',
                Terminal: 'false',
                Type: 'Application',
                Categories: 'Utility;Application;',
                StartupWMClass: 'UnderWebX',
                MimeType: 'x-scheme-handler/uwx;'
            }
        },
        maintainer: 'rs189 <35667100+rs189@users.noreply.github.com>',
        description: 'UnderWeb VRChat network control client',
        syncDesktopName: true
    },
    mac: {
        artifactName: 'UnderWebX_Version.${ext}',
        target: ['dmg'],
        icon: 'images/VRCX.png',
        category: 'public.app-category.utilities',
        executableName: 'UnderWebX'
    },
    toolsets: {
        appimage: '1.0.3'
    }
};
