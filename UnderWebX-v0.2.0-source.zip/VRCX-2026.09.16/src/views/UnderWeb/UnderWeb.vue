<template>
    <div class="x-container uwx-page">
        <div class="uwx-hero">
            <div>
                <div class="uwx-kicker">UNDERWEB // NETWORK</div>
                <h1 class="uwx-title">UnderWeb X</h1>
                <p class="uwx-subtitle">VRChat network control, group-instance tools, and live friend radar.</p>
            </div>
            <div class="uwx-instance-badge" :class="statusClass">
                <span class="uwx-status-dot"></span>
                <span>{{ statusText }}</span>
            </div>
        </div>

        <div class="uwx-overview">
            <div class="uwx-overview-tile">
                <span>WORLD</span>
                <strong>{{ currentWorldName }}</strong>
                <small>{{ currentParsedLocation.instanceName || 'No active instance' }}</small>
            </div>
            <div class="uwx-overview-tile">
                <span>INSTANCE</span>
                <strong>{{ currentPlayerCount }} player{{ currentPlayerCount === 1 ? '' : 's' }}</strong>
                <small>{{ currentFriendsHere }} friend{{ currentFriendsHere === 1 ? '' : 's' }} here</small>
            </div>
            <div class="uwx-overview-tile">
                <span>FRIENDS ONLINE</span>
                <strong>{{ onlineFriendsCount }}</strong>
                <small>{{ favoriteOnlineCount }} favorite{{ favoriteOnlineCount === 1 ? '' : 's' }}</small>
            </div>
            <div class="uwx-overview-tile">
                <span>UWX SESSION</span>
                <strong>{{ sessionInvitesSent }} invite{{ sessionInvitesSent === 1 ? '' : 's' }}</strong>
                <small>{{ allowedGroupIds.length }} approved group{{ allowedGroupIds.length === 1 ? '' : 's' }}</small>
            </div>
        </div>

        <div class="uwx-grid">
            <Card class="uwx-card uwx-card-wide">
                <CardHeader>
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <CardTitle>Group Instance Control</CardTitle>
                            <CardDescription>
                                Auto Invite only arms inside explicitly approved group instances. Choose the audience, keep
                                exclusions local, and kill the queue instantly by disarming it.
                            </CardDescription>
                        </div>
                        <Switch :model-value="autoInviteEnabled" @update:modelValue="setAutoInviteEnabled" />
                    </div>
                </CardHeader>
                <CardContent class="space-y-5">
                    <div class="uwx-stat-row">
                        <div class="uwx-stat">
                            <span class="uwx-stat-label">CURRENT GROUP</span>
                            <strong>{{ currentGroupId || 'Not in a group instance' }}</strong>
                        </div>
                        <div class="uwx-stat">
                            <span class="uwx-stat-label">SCOPE</span>
                            <strong>{{ inviteScopeLabel }}</strong>
                        </div>
                        <div class="uwx-stat">
                            <span class="uwx-stat-label">ELIGIBLE NOW</span>
                            <strong>{{ eligibleInviteFriends.length }}</strong>
                        </div>
                        <div class="uwx-stat">
                            <span class="uwx-stat-label">COOLDOWN</span>
                            <strong>{{ cooldownMinutes }}m</strong>
                        </div>
                    </div>

                    <div>
                        <div class="uwx-section-label">INVITE AUDIENCE</div>
                        <div class="flex flex-wrap gap-2 mt-2">
                            <Button
                                :variant="inviteScope === 'selected' ? 'default' : 'outline'"
                                @click="setInviteScope('selected')">
                                Selected ({{ selectedUserIds.length }})
                            </Button>
                            <Button
                                :variant="inviteScope === 'favorites' ? 'default' : 'outline'"
                                @click="setInviteScope('favorites')">
                                Favorites ({{ favoriteOnlineCount }})
                            </Button>
                            <Button
                                :variant="inviteScope === 'all-online' ? 'default' : 'outline'"
                                @click="setInviteScope('all-online')">
                                All Online ({{ onlineFriendsCount }})
                            </Button>
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-2">
                        <Button
                            v-if="currentGroupId && !isCurrentGroupAllowed"
                            variant="default"
                            @click="addCurrentGroup">
                            Allow current group
                        </Button>
                        <Button
                            v-if="currentGroupId && isCurrentGroupAllowed"
                            variant="outline"
                            @click="removeAllowedGroup(currentGroupId)">
                            Remove current group
                        </Button>
                        <Button :disabled="isScanning || !canAutoInviteHere" variant="secondary" @click="inviteNow">
                            <i :class="isScanning ? 'ri-loader-4-line animate-spin' : 'ri-send-plane-2-line'" />
                            Invite eligible now
                        </Button>
                    </div>

                    <div class="uwx-warning">
                        <strong>Guardrails:</strong> UWX refuses to auto-invite outside an approved <code>grp_</code>
                        instance, skips people already with you, respects the per-user cooldown, honors the do-not-invite
                        list, and stops the active queue if your instance changes.
                    </div>
                </CardContent>
            </Card>

            <Card class="uwx-card">
                <CardHeader>
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <CardTitle>Network Radar</CardTitle>
                            <CardDescription>Live friend clusters from presence data already available to VRCX.</CardDescription>
                        </div>
                        <Badge variant="outline">{{ radarClusters.length }} clusters</Badge>
                    </div>
                </CardHeader>
                <CardContent>
                    <div v-if="radarClusters.length" class="uwx-radar-list">
                        <button
                            v-for="cluster in radarClusters"
                            :key="cluster.location"
                            class="uwx-radar-row"
                            type="button"
                            @click="openFriendsLocations">
                            <div class="min-w-0 text-left">
                                <div class="flex items-center gap-2">
                                    <strong class="truncate">{{ cluster.label }}</strong>
                                    <Badge v-if="cluster.isNetworkGroup" variant="default">UNDERWEB</Badge>
                                </div>
                                <div class="text-xs text-muted-foreground truncate">
                                    {{ cluster.names.join(', ') }}
                                </div>
                            </div>
                            <div class="uwx-radar-count">{{ cluster.count }}</div>
                        </button>
                    </div>
                    <p v-else class="text-sm text-muted-foreground">No visible friend clusters right now.</p>
                </CardContent>
            </Card>

            <Card class="uwx-card">
                <CardHeader>
                    <CardTitle>UnderWeb Quick Access</CardTitle>
                    <CardDescription>Jump between the desktop client and the network.</CardDescription>
                </CardHeader>
                <CardContent class="uwx-quick-grid">
                    <Button variant="outline" @click="openUnderWeb">
                        <i class="ri-global-line" />
                        underweb.cloud
                    </Button>
                    <Button variant="outline" @click="openUnderWebEvents">
                        <i class="ri-calendar-event-line" />
                        Events
                    </Button>
                    <Button variant="outline" @click="openFriendsLocations">
                        <i class="ri-user-location-line" />
                        Friends Radar
                    </Button>
                    <Button variant="outline" @click="openGroups">
                        <i class="ri-group-2-line" />
                        VRChat Groups
                    </Button>
                </CardContent>
            </Card>

            <Card class="uwx-card">
                <CardHeader>
                    <CardTitle>Allowed groups</CardTitle>
                    <CardDescription>Only these group IDs can arm Auto Invite.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div class="flex gap-2 mb-3">
                        <Input v-model="groupInput" placeholder="grp_..." @keyup.enter="addGroupFromInput" />
                        <Button variant="outline" @click="addGroupFromInput">Add</Button>
                    </div>
                    <div v-if="allowedGroupIds.length" class="space-y-2">
                        <div v-for="groupId in allowedGroupIds" :key="groupId" class="uwx-list-row">
                            <code class="truncate">{{ groupId }}</code>
                            <Button size="sm" variant="ghost" @click="removeAllowedGroup(groupId)">Remove</Button>
                        </div>
                    </div>
                    <p v-else class="text-sm text-muted-foreground">No groups allowed yet.</p>
                </CardContent>
            </Card>

            <Card class="uwx-card">
                <CardHeader>
                    <CardTitle>Safety controls</CardTitle>
                    <CardDescription>Invite pacing, repeat protection, and exclusions.</CardDescription>
                </CardHeader>
                <CardContent class="space-y-4">
                    <div>
                        <label class="text-sm font-medium">Per-user cooldown (minutes)</label>
                        <Input
                            class="mt-2"
                            type="number"
                            min="1"
                            max="1440"
                            :model-value="cooldownMinutes"
                            @change="updateCooldown" />
                    </div>
                    <div class="uwx-list-row">
                        <span>Do-not-invite list</span>
                        <Badge variant="outline">{{ excludedUserIds.length }}</Badge>
                    </div>
                    <div class="uwx-list-row">
                        <span>Send pacing</span>
                        <Badge variant="outline">2.5 sec</Badge>
                    </div>
                    <div class="uwx-list-row">
                        <span>Background scan</span>
                        <Badge variant="outline">15 sec</Badge>
                    </div>
                    <div class="uwx-list-row">
                        <span>Last scan</span>
                        <Badge variant="outline">{{ lastScanText }}</Badge>
                    </div>
                </CardContent>
            </Card>

            <Card class="uwx-card uwx-card-wide">
                <CardHeader>
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <CardTitle>Invite List & Exclusions</CardTitle>
                            <CardDescription>
                                Select people for Selected mode. The shield icon blocks a user from every invite scope.
                            </CardDescription>
                        </div>
                        <Badge variant="outline">{{ filteredFriends.length }} shown</Badge>
                    </div>
                </CardHeader>
                <CardContent>
                    <Input v-model="friendSearch" class="mb-3" placeholder="Search friends..." />
                    <div class="uwx-friend-list">
                        <div
                            v-for="friend in filteredFriends"
                            :key="friend.id"
                            class="uwx-friend-row"
                            :class="{
                                selected: selectedUserIds.includes(friend.id),
                                excluded: excludedUserIds.includes(friend.id)
                            }">
                            <button class="uwx-friend-main" type="button" @click="toggleSelectedUser(friend.id)">
                                <div class="min-w-0 text-left">
                                    <div class="font-medium truncate">{{ friend.displayName }}</div>
                                    <div class="text-xs text-muted-foreground truncate">{{ friend.id }}</div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <Badge v-if="excludedUserIds.includes(friend.id)" variant="destructive">NO INVITE</Badge>
                                    <Badge :variant="friend.state === 'online' ? 'default' : 'outline'">{{ friend.state }}</Badge>
                                    <i
                                        :class="
                                            selectedUserIds.includes(friend.id)
                                                ? 'ri-checkbox-circle-fill text-primary'
                                                : 'ri-checkbox-blank-circle-line text-muted-foreground'
                                        "
                                        class="text-lg" />
                                </div>
                            </button>
                            <Button
                                size="icon"
                                :variant="excludedUserIds.includes(friend.id) ? 'destructive' : 'ghost'"
                                :title="excludedUserIds.includes(friend.id) ? 'Allow invites again' : 'Never auto-invite this user'"
                                @click="toggleExcludedUser(friend.id)">
                                <i :class="excludedUserIds.includes(friend.id) ? 'ri-shield-check-fill' : 'ri-shield-line'" />
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card class="uwx-card uwx-card-wide">
                <CardHeader>
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <CardTitle>UWX activity</CardTitle>
                            <CardDescription>Local activity log for the UnderWeb control layer.</CardDescription>
                        </div>
                        <Button size="sm" variant="ghost" @click="clearActivityLog">Clear</Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <div v-if="activityLog.length" class="uwx-log-list">
                        <div v-for="entry in activityLog" :key="entry.id" class="uwx-log-row">
                            <span class="uwx-log-time">{{ formatTime(entry.at) }}</span>
                            <Badge :variant="entry.level === 'error' ? 'destructive' : 'outline'">{{ entry.level }}</Badge>
                            <span class="min-w-0 break-words">{{ entry.message }}</span>
                        </div>
                    </div>
                    <p v-else class="text-sm text-muted-foreground">Nothing logged yet.</p>
                </CardContent>
            </Card>
        </div>
    </div>
</template>

<script setup>
    import { computed, ref } from 'vue';
    import { storeToRefs } from 'pinia';
    import { useRouter } from 'vue-router';
    import { Badge } from '@/components/ui/badge';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Switch } from '@/components/ui/switch';

    import { openExternalLink, parseLocation } from '../../shared/utils';
    import { useFriendStore, useLocationStore, useUnderWebStore } from '../../stores';

    const router = useRouter();
    const underWebStore = useUnderWebStore();
    const friendStore = useFriendStore();
    const locationStore = useLocationStore();
    const {
        autoInviteEnabled,
        allowedGroupIds,
        selectedUserIds,
        excludedUserIds,
        inviteScope,
        cooldownMinutes,
        isScanning,
        lastScanAt,
        activityLog,
        sessionInvitesSent,
        currentGroupId,
        currentParsedLocation,
        isGroupInstance,
        isCurrentGroupAllowed,
        canAutoInviteHere,
        eligibleInviteFriends
    } = storeToRefs(underWebStore);

    const {
        setAutoInviteEnabled,
        setInviteScope,
        setCooldownMinutes,
        addAllowedGroup,
        removeAllowedGroup,
        toggleSelectedUser,
        toggleExcludedUser,
        clearActivityLog,
        scanAndInvite
    } = underWebStore;

    const groupInput = ref('');
    const friendSearch = ref('');

    const allFriends = computed(() => {
        return Array.from(friendStore.friends.values())
            .map((ctx) => ({
                id: ctx.id,
                state: ctx.state || 'offline',
                displayName: ctx.ref?.displayName || ctx.name || ctx.id,
                location: ctx.ref?.$location?.tag || ctx.ref?.location || ''
            }))
            .sort((a, b) => {
                if (a.state === 'online' && b.state !== 'online') return -1;
                if (b.state === 'online' && a.state !== 'online') return 1;
                return a.displayName.localeCompare(b.displayName);
            });
    });

    const filteredFriends = computed(() => {
        const q = friendSearch.value.trim().toLowerCase();
        if (!q) return allFriends.value;
        return allFriends.value.filter(
            (friend) => friend.displayName.toLowerCase().includes(q) || friend.id.toLowerCase().includes(q)
        );
    });

    const onlineFriendsCount = computed(() => allFriends.value.filter((friend) => friend.state === 'online').length);
    const favoriteOnlineCount = computed(() => friendStore.allFavoriteOnlineFriends.length);
    const currentPlayerCount = computed(() => locationStore.lastLocation.playerList?.size || 0);
    const currentFriendsHere = computed(() => locationStore.lastLocation.friendList?.size || 0);
    const currentWorldName = computed(() => locationStore.lastLocation.name || currentParsedLocation.value.worldId || 'VRChat');

    const inviteScopeLabel = computed(() => {
        if (inviteScope.value === 'favorites') return 'Favorite friends';
        if (inviteScope.value === 'all-online') return 'All online friends';
        return 'Selected friends';
    });

    const lastScanText = computed(() => {
        if (!lastScanAt.value) return 'Not yet';
        return new Date(lastScanAt.value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    });

    const radarClusters = computed(() => {
        const clusters = new Map();
        for (const friend of allFriends.value) {
            if (friend.state !== 'online' || !friend.location) continue;
            const parsed = parseLocation(friend.location);
            if (!parsed.isRealInstance || !parsed.instanceId) continue;
            const existing = clusters.get(parsed.tag) || {
                location: parsed.tag,
                worldId: parsed.worldId,
                instanceName: parsed.instanceName,
                groupId: parsed.groupId || '',
                count: 0,
                names: []
            };
            existing.count += 1;
            if (existing.names.length < 4) {
                existing.names.push(friend.displayName);
            }
            clusters.set(parsed.tag, existing);
        }
        return [...clusters.values()]
            .map((cluster) => ({
                ...cluster,
                isNetworkGroup: Boolean(cluster.groupId && allowedGroupIds.value.includes(cluster.groupId)),
                label: `${cluster.worldId || 'World'} · ${cluster.instanceName || 'instance'}`
            }))
            .sort((a, b) => {
                if (a.isNetworkGroup !== b.isNetworkGroup) return a.isNetworkGroup ? -1 : 1;
                return b.count - a.count;
            })
            .slice(0, 6);
    });

    const statusText = computed(() => {
        if (!isGroupInstance.value) return 'NOT IN GROUP INSTANCE';
        if (!isCurrentGroupAllowed.value) return 'GROUP NOT ALLOWED';
        if (!autoInviteEnabled.value) return 'READY / DISARMED';
        return 'AUTO INVITE ARMED';
    });

    const statusClass = computed(() => ({
        ready: canAutoInviteHere.value && !autoInviteEnabled.value,
        armed: canAutoInviteHere.value && autoInviteEnabled.value,
        blocked: !canAutoInviteHere.value
    }));

    async function addCurrentGroup() {
        if (currentGroupId.value) {
            await addAllowedGroup(currentGroupId.value);
        }
    }

    async function addGroupFromInput() {
        if (await addAllowedGroup(groupInput.value)) {
            groupInput.value = '';
        }
    }

    function updateCooldown(event) {
        void setCooldownMinutes(event.target.value);
    }

    function inviteNow() {
        void scanAndInvite({ source: 'manual', force: true });
    }

    function openUnderWeb() {
        openExternalLink('https://underweb.cloud');
    }

    function openUnderWebEvents() {
        openExternalLink('https://underweb.cloud/events');
    }

    function openFriendsLocations() {
        router.push({ name: 'friends-locations' });
    }

    function openGroups() {
        openExternalLink('https://vrchat.com/home/groups');
    }

    function formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
</script>

<style scoped>
    .uwx-page {
        background:
            radial-gradient(circle at 12% 0%, rgb(103 255 0 / 9%), transparent 30%),
            linear-gradient(180deg, rgb(0 0 0 / 10%), transparent 30%),
            var(--sidebar);
    }

    .uwx-hero {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 24px;
        padding: 18px 18px 22px;
        border-bottom: 1px solid rgb(118 255 0 / 20%);
        margin-bottom: 16px;
    }

    .uwx-kicker {
        font-size: 11px;
        letter-spacing: 0.28em;
        color: #76ff00;
        font-weight: 800;
    }

    .uwx-title {
        margin: 4px 0 0;
        font-size: clamp(30px, 4vw, 54px);
        line-height: 0.95;
        font-weight: 900;
        letter-spacing: -0.045em;
    }

    .uwx-subtitle {
        margin: 10px 0 0;
        color: var(--muted-foreground);
    }

    .uwx-instance-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 10px;
        border: 1px solid var(--border);
        border-radius: 999px;
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 0.08em;
        white-space: nowrap;
    }

    .uwx-status-dot {
        width: 7px;
        height: 7px;
        border-radius: 999px;
        background: #6b7280;
    }
    .uwx-instance-badge.armed { border-color: rgb(118 255 0 / 55%); color: #76ff00; }
    .uwx-instance-badge.armed .uwx-status-dot { background: #76ff00; box-shadow: 0 0 14px #76ff00; }
    .uwx-instance-badge.ready .uwx-status-dot { background: #eab308; }
    .uwx-instance-badge.blocked { opacity: 0.7; }

    .uwx-overview {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 10px;
        margin: 0 0 14px;
    }

    .uwx-overview-tile {
        min-width: 0;
        padding: 12px 14px;
        border: 1px solid rgb(118 255 0 / 14%);
        border-radius: var(--radius);
        background: color-mix(in oklab, var(--card) 95%, #76ff00 5%);
    }
    .uwx-overview-tile span,
    .uwx-section-label {
        color: #76ff00;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.12em;
    }
    .uwx-overview-tile strong,
    .uwx-overview-tile small {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .uwx-overview-tile strong { margin-top: 6px; font-size: 15px; }
    .uwx-overview-tile small { margin-top: 2px; color: var(--muted-foreground); }

    .uwx-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 14px;
    }

    .uwx-card {
        border-color: rgb(118 255 0 / 10%);
        background: color-mix(in oklab, var(--card) 94%, #76ff00 6%);
    }

    .uwx-card-wide { grid-column: 1 / -1; }

    .uwx-stat-row {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 10px;
    }

    .uwx-stat,
    .uwx-list-row,
    .uwx-warning {
        border: 1px solid var(--border);
        background: rgb(0 0 0 / 10%);
        border-radius: var(--radius);
    }

    .uwx-stat { padding: 12px; min-width: 0; }
    .uwx-stat strong { display: block; margin-top: 5px; overflow: hidden; text-overflow: ellipsis; }
    .uwx-stat-label { color: #76ff00; font-size: 10px; font-weight: 800; letter-spacing: 0.12em; }
    .uwx-list-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 9px 10px; }
    .uwx-warning { padding: 10px 12px; color: var(--muted-foreground); font-size: 12px; border-color: rgb(234 179 8 / 25%); }

    .uwx-quick-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
    }

    .uwx-radar-list,
    .uwx-friend-list,
    .uwx-log-list {
        max-height: 360px;
        overflow: auto;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .uwx-radar-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--border);
        border-radius: var(--radius);
        background: transparent;
        cursor: pointer;
    }
    .uwx-radar-row:hover { border-color: rgb(118 255 0 / 30%); background: rgb(118 255 0 / 5%); }
    .uwx-radar-count {
        display: grid;
        place-items: center;
        min-width: 32px;
        height: 32px;
        padding: 0 8px;
        border-radius: 999px;
        background: rgb(118 255 0 / 10%);
        color: #76ff00;
        font-weight: 900;
    }

    .uwx-friend-row {
        display: flex;
        width: 100%;
        align-items: center;
        gap: 8px;
        padding: 4px;
        border: 1px solid var(--border);
        border-radius: var(--radius);
        background: transparent;
    }
    .uwx-friend-row:hover { background: rgb(118 255 0 / 5%); }
    .uwx-friend-row.selected { border-color: rgb(118 255 0 / 38%); background: rgb(118 255 0 / 7%); }
    .uwx-friend-row.excluded { border-color: rgb(239 68 68 / 32%); }
    .uwx-friend-main {
        display: flex;
        flex: 1;
        min-width: 0;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 6px 8px;
        background: transparent;
        cursor: pointer;
    }

    .uwx-log-row {
        display: grid;
        grid-template-columns: 76px 78px minmax(0, 1fr);
        align-items: center;
        gap: 10px;
        padding: 8px 0;
        border-bottom: 1px solid var(--border);
        font-size: 12px;
    }
    .uwx-log-time { color: var(--muted-foreground); font-variant-numeric: tabular-nums; }

    @media (max-width: 1100px) {
        .uwx-overview { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }

    @media (max-width: 900px) {
        .uwx-grid { grid-template-columns: 1fr; }
        .uwx-card-wide { grid-column: auto; }
        .uwx-stat-row { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .uwx-hero { flex-direction: column; }
    }
</style>
