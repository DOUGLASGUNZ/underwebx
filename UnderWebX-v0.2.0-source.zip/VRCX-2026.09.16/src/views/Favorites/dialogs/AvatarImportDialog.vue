<template>
    <Dialog v-model:open="isVisible">
        <DialogContent class="sm:max-w-xl">
            <DialogHeader>
                <DialogTitle>{{ t('dialog.avatar_import.header') }}</DialogTitle>
            </DialogHeader>
            <div style="display: flex; align-items: center; justify-content: space-between">
                <div class="text-xs">{{ t('dialog.avatar_import.description') }}</div>
                <div style="display: flex; align-items: center">
                    <div v-if="avatarImportDialog.progress">
                        {{ t('dialog.avatar_import.process_progress') }} {{ avatarImportDialog.progress }} /
                        {{ avatarImportDialog.progressTotal }}
                        <Spinner class="inline-block ml-2 mr-2" />
                    </div>
                    <Button v-if="avatarImportDialog.loading" size="sm" variant="secondary" @click="cancelAvatarImport">
                        {{ t('dialog.avatar_import.cancel') }}
                    </Button>
                    <Button size="sm" v-else :disabled="!avatarImportDialog.input" @click="processAvatarImportList">
                        {{ t('dialog.avatar_import.process_list') }}
                    </Button>
                </div>
            </div>
            <InputGroupTextareaField v-model="avatarImportDialog.input" :rows="10" input-class="resize-none mt-2" />
            <div class="mt-1.5" style="display: flex; align-items: center; justify-content: space-between">
                <div>
                    <div class="flex items-center gap-2">
                        <Select
                            class="mr-1.5"
                            :model-value="avatarImportFavoriteGroupSelection"
                            @update:modelValue="handleAvatarImportGroupSelect">
                            <SelectTrigger size="sm">
                                <SelectValue :placeholder="t('dialog.avatar_import.select_group_placeholder')" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectGroup>
                                    <SelectItem
                                        v-for="groupAPI in favoriteAvatarGroups"
                                        :key="groupAPI.name"
                                        :value="groupAPI.name"
                                        :disabled="groupAPI.count >= groupAPI.capacity">
                                        {{ groupAPI.displayName }} ({{ groupAPI.count }}/{{ groupAPI.capacity }})
                                    </SelectItem>
                                </SelectGroup>
                            </SelectContent>
                        </Select>

                        <Select
                            class="ml-2"
                            :model-value="avatarImportLocalFavoriteGroupSelection"
                            @update:modelValue="handleAvatarImportLocalGroupSelect">
                            <SelectTrigger size="sm">
                                <SelectValue :placeholder="t('dialog.avatar_import.select_group_placeholder')" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectGroup>
                                    <SelectItem v-for="group in localAvatarFavoriteGroups" :key="group" :value="group">
                                        {{ group }} ({{ localAvatarFavGroupLength(group) }})
                                    </SelectItem>
                                </SelectGroup>
                            </SelectContent>
                        </Select>
                    </div>
                    <span class="ml-1.5" v-if="avatarImportDialog.avatarImportFavoriteGroup">
                        {{ avatarImportTable.data.length }} /
                        {{
                            avatarImportDialog.avatarImportFavoriteGroup.capacity -
                            avatarImportDialog.avatarImportFavoriteGroup.count
                        }}
                    </span>
                </div>
                <div>
                    <Button size="sm" variant="secondary" class="mr-2" @click="clearAvatarImportTable">
                        {{ t('dialog.avatar_import.clear_table') }}
                    </Button>
                    <Button
                        size="sm"
                        :disabled="
                            avatarImportTable.data.length === 0 ||
                            (!avatarImportDialog.avatarImportFavoriteGroup &&
                                !avatarImportDialog.avatarImportLocalFavoriteGroup)
                        "
                        @click="importAvatarImportTable">
                        {{ t('dialog.avatar_import.import') }}
                    </Button>
                </div>
            </div>
            <span class="m-2" v-if="avatarImportDialog.importProgress">
                <Spinner class="inline-block ml-2 mr-2" />
                {{ t('dialog.avatar_import.import_progress') }}
                {{ avatarImportDialog.importProgress }}/{{ avatarImportDialog.importProgressTotal }}
            </span>
            <br />
            <template v-if="avatarImportDialog.errors">
                <Button size="sm" variant="secondary" @click="avatarImportDialog.errors = ''">
                    {{ t('dialog.avatar_import.clear_errors') }}
                </Button>
                <h2 class="my-1.5 mx-0" style="font-weight: bold">
                    {{ t('dialog.avatar_import.errors') }}
                </h2>
                <pre class="whitespace-pre-wrap text-xs" v-text="avatarImportDialog.errors"></pre>
            </template>
            <DataTableLayout
                class="min-w-0 w-full"
                :table="table"
                :loading="avatarImportDialog.loading"
                :table-style="tableStyle"
                :show-pagination="false"
                style="margin-top: 8px" />
        </DialogContent>
    </Dialog>
</template>

<script setup>
    import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
    import { computed, ref, watch } from 'vue';
    import { Button } from '@/components/ui/button';
    import { DataTableLayout } from '@/components/ui/data-table';
    import { InputGroupTextareaField } from '@/components/ui/input-group';
    import { Spinner } from '@/components/ui/spinner';
    import { storeToRefs } from 'pinia';
    import { toast } from 'vue-sonner';
    import { useI18n } from 'vue-i18n';

    import { useAvatarStore, useFavoriteStore, useGalleryStore, useUserStore } from '../../../stores';
    import { addLocalAvatarFavorite } from '../../../coordinators/favoriteCoordinator';
    import { avatarRequest, favoriteRequest } from '../../../api';
    import { createColumns } from './avatarImportColumns.jsx';
    import { removeFromArray } from '../../../shared/utils';
    import { useVrcxVueTable } from '../../../lib/table/useVrcxVueTable';

    const emit = defineEmits(['update:avatarImportDialogInput']);
    const { t } = useI18n();

    const { favoriteAvatarGroups, avatarImportDialogInput, avatarImportDialogVisible, localAvatarFavoriteGroups } =
        storeToRefs(useFavoriteStore());
    const { localAvatarFavGroupLength, getCachedFavoritesByObjectId } = useFavoriteStore();
    import { showAvatarDialog, applyAvatar } from '../../../coordinators/avatarCoordinator';
    import { showUserDialog } from '../../../coordinators/userCoordinator';
    const { showFullscreenImageDialog } = useGalleryStore();

    const avatarImportDialog = ref({
        loading: false,
        progress: 0,
        progressTotal: 0,
        input: '',
        avatarIdList: new Set(),
        errors: '',
        avatarImportFavoriteGroup: null,
        avatarImportLocalFavoriteGroup: null,
        importProgress: 0,
        importProgressTotal: 0
    });

    const avatarImportFavoriteGroupSelection = ref('');
    const avatarImportLocalFavoriteGroupSelection = ref('');

    const avatarImportTable = ref({
        data: [],
        layout: 'table'
    });

    const tableStyle = { maxHeight: '400px' };

    const rows = computed(() =>
        Array.isArray(avatarImportTable.value?.data) ? avatarImportTable.value.data.slice() : []
    );

    const columns = computed(() =>
        createColumns({
            onShowAvatar: showAvatarDialog,
            onShowUser: showUserDialog,
            onShowFullscreenImage: showFullscreenImageDialog,
            onDelete: deleteItemAvatarImport
        })
    );

    const { table } = useVrcxVueTable({
        persistKey: 'avatarImportDialog',
        get data() {
            return rows.value;
        },
        columns: columns.value,
        getRowId: (row) => String(row?.id ?? ''),
        enablePagination: false,
        enableSorting: false
    });

    const isVisible = computed({
        get() {
            return avatarImportDialogVisible.value;
        },
        set(value) {
            avatarImportDialogVisible.value = value;
        }
    });

    watch(
        () => avatarImportDialogVisible.value,
        (value) => {
            if (value) {
                clearAvatarImportTable();
                resetAvatarImport();
                if (avatarImportDialogInput.value) {
                    avatarImportDialog.value.input = avatarImportDialogInput.value;
                    processAvatarImportList();
                    emit('update:avatarImportDialogInput', '');
                }
            }
        }
    );

    async function processAvatarImportList() {
        const D = avatarImportDialog.value;
        D.loading = true;
        const regexAvatarId = /avtr_[0-9A-Fa-f]{8}-([0-9A-Fa-f]{4}-){3}[0-9A-Fa-f]{12}/g;
        let match = [];
        const avatarIdList = new Set();
        while ((match = regexAvatarId.exec(D.input)) !== null) {
            avatarIdList.add(match[0]);
        }
        D.input = '';
        D.errors = '';
        D.progress = 0;
        D.progressTotal = avatarIdList.size;
        const data = Array.from(avatarIdList);
        for (let i = 0; i < data.length; ++i) {
            if (!isVisible.value) {
                resetAvatarImport();
            }
            if (!D.loading || !isVisible.value) {
                break;
            }
            const avatarId = data[i];
            if (!D.avatarIdList.has(avatarId)) {
                try {
                    const args = await avatarRequest.getAvatar({
                        avatarId
                    });
                    const ref = applyAvatar(args.json);
                    avatarImportTable.value.data.push(ref);
                    D.avatarIdList.add(avatarId);
                } catch (err) {
                    D.errors = D.errors.concat(`AvatarId: ${avatarId}\n${err}\n\n`);
                }
            }
            D.progress++;
        }
        D.loading = false;
        D.progress = 0;
        D.progressTotal = 0;
    }

    /**
     * @param ref
     */
    function deleteItemAvatarImport(ref) {
        removeFromArray(avatarImportTable.value.data, ref);
        avatarImportDialog.value.avatarIdList.delete(ref.id);
    }

    function resetAvatarImport() {
        avatarImportDialog.value.input = '';
        avatarImportDialog.value.errors = '';
    }

    function clearAvatarImportTable() {
        avatarImportTable.value.data = [];
        avatarImportDialog.value.avatarIdList = new Set();
    }

    /**
     * @param group
     */
    function selectAvatarImportGroup(group) {
        avatarImportDialog.value.avatarImportLocalFavoriteGroup = null;
        avatarImportDialog.value.avatarImportFavoriteGroup = group;
        avatarImportFavoriteGroupSelection.value = group?.name ?? '';
        avatarImportLocalFavoriteGroupSelection.value = '';
    }

    /**
     * @param group
     */
    function selectAvatarImportLocalGroup(group) {
        avatarImportDialog.value.avatarImportFavoriteGroup = null;
        avatarImportDialog.value.avatarImportLocalFavoriteGroup = group;
        avatarImportFavoriteGroupSelection.value = '';
        avatarImportLocalFavoriteGroupSelection.value = group ?? '';
    }

    /**
     * @param value
     */
    function handleAvatarImportGroupSelect(value) {
        avatarImportFavoriteGroupSelection.value = value;
        const group = favoriteAvatarGroups.value.find((g) => g.name === value) ?? null;
        selectAvatarImportGroup(group);
    }

    /**
     * @param value
     */
    function handleAvatarImportLocalGroupSelect(value) {
        avatarImportLocalFavoriteGroupSelection.value = value;
        selectAvatarImportLocalGroup(value || null);
    }

    function cancelAvatarImport() {
        avatarImportDialog.value.loading = false;
    }
    /**
     * @param ref
     * @param group
     * @param message
     */
    function addFavoriteAvatar(ref, group, message) {
        return favoriteRequest
            .addFavorite({
                type: group.type,
                favoriteId: ref.id,
                tags: group.name
            })
            .then((args) => {
                if (message) {
                    toast.success('Avatar added to favorites');
                }
                return args;
            });
    }
    async function importAvatarImportTable() {
        const D = avatarImportDialog.value;
        if (!D.avatarImportFavoriteGroup && !D.avatarImportLocalFavoriteGroup) {
            return;
        }
        D.loading = true;
        const data = [...avatarImportTable.value.data].reverse();
        D.importProgressTotal = data.length;
        let ref = null;
        try {
            for (let i = data.length - 1; i >= 0; i--) {
                if (!D.loading || !isVisible.value) {
                    break;
                }
                ref = data[i];
                if (D.avatarImportFavoriteGroup) {
                    if (getCachedFavoritesByObjectId(ref.id)) {
                        throw new Error('Avatar is already in favorites');
                    }
                    await addFavoriteAvatar(ref, D.avatarImportFavoriteGroup, false);
                } else if (D.avatarImportLocalFavoriteGroup) {
                    addLocalAvatarFavorite(ref.id, D.avatarImportLocalFavoriteGroup);
                }
                removeFromArray(avatarImportTable.value.data, ref);
                D.avatarIdList.delete(ref.id);
                D.importProgress++;
            }
        } catch (err) {
            D.errors = `Name: ${ref?.name}\nAvatarId: ${ref?.id}\n${err}\n\n`;
        } finally {
            D.importProgress = 0;
            D.importProgressTotal = 0;
            D.loading = false;
        }
    }
</script>
