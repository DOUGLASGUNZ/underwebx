# UnderWeb X changelog

## 0.1.0

- Created UnderWeb X fork foundation from VRCX 2026.09.16.
- Added dedicated UnderWeb control-center route and first-class navigation entry.
- Added group-instance-scoped Auto Invite engine.
- Added explicit allowed-group list and explicit per-friend invite allowlist.
- Added manual invite scan, 15-second background scans, 2.5-second pacing, persistent cooldown/deduplication, in-flight disarm, instance-change abort, and HTTP 429 backoff.
- Added UWX activity log.
- Isolated Windows/Electron application data from stock VRCX.
- Renamed Windows CEF executable to `UnderWebX.exe`.
- Added `uwx://` protocol identity.
- Disabled upstream updater.
- Added UnderWeb X login/nav branding while preserving the VRCX MIT license and upstream attribution.
