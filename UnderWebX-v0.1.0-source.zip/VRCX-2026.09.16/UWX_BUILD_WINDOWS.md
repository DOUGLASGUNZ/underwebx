# UnderWeb X — Windows build

## Requirements

- Windows 10/11 x64
- Node.js **24.15.0 or newer**
- npm **11.5.0 or newer**
- .NET 10 SDK
- Visual Studio / MSBuild components required by the upstream VRCX CEF build
- 7-Zip CLI available as `7z`
- NSIS installed at the path used by `build-scripts/build-all.ps1`

## Full Windows build

From PowerShell in the repository root:

```powershell
pwsh ./build-scripts/build-all.ps1
```

The UWX-modified build pipeline outputs artifacts named like:

- `UnderWebX_YYYYMMDD.zip`
- `UnderWebX_YYYYMMDD_Setup.exe`

The installed executable is `UnderWebX.exe` under `Program Files\UnderWebX`.

## Front-end development

```powershell
npm ci
npm run dev
```

The repo intentionally keeps VRCX's internal .NET namespaces, bridge class names, SQLite filename, and many `VRCX_*` config keys. Those are compatibility internals. The application data directory itself is isolated to `%APPDATA%\UnderWebX`.

## Updater

The upstream VRCX updater is disabled in UWX v0.1. Do not re-enable it unless UWX has its own release/update channel; otherwise an upstream update could overwrite fork-specific behavior.
