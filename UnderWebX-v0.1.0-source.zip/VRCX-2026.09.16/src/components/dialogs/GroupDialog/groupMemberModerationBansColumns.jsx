import { Checkbox } from '@/components/ui/checkbox';
import { i18n } from '@/plugins';
import { formatDateFilter } from '@/shared/utils';
import { Button } from '@/components/ui/button';
import { ArrowUpDown } from 'lucide-vue-next';
import { TooltipWrapper } from '@/components/ui/tooltip';

const { t } = i18n.global;

const sortButton = ({ column, label, descFirst = false }) => (
    <Button
        variant="ghost"
        size="sm"
        class="-ml-2 h-8 px-2"
        onClick={() => {
            const sorted = column.getIsSorted();
            if (!sorted && descFirst) {
                column.toggleSorting(true);
                return;
            }
            column.toggleSorting(sorted === 'asc');
        }}
    >
        {label}
        <ArrowUpDown class="ml-1 h-4 w-4" />
    </Button>
);

export const createColumns = ({
    randomUserColours,
    rolesText,
    userImage,
    userImageFull,
    onShowFullscreenImage,
    onShowUser,
    onSelectionChange
}) => [
    {
        id: 'selected',
        header: () => null,
        size: 55,
        enableSorting: false,
        cell: ({ row }) => {
            const original = row.original;
            return (
                <div class="flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                        modelValue={!!original?.$selected}
                        onUpdate:modelValue={(value) => {
                            original.$selected = value;
                            onSelectionChange?.(original);
                        }}
                    />
                </div>
            );
        }
    },
    {
        id: 'avatar',
        header: () => t('dialog.group_member_moderation.avatar'),
        size: 70,
        enableSorting: false,
        cell: ({ row }) => {
            const original = row.original;
            const thumb = userImage?.(original?.user);
            const full = userImageFull?.(original?.user);

            return (
                <img
                    src={thumb}
                    class="friends-list-avatar"
                    loading="lazy"
                    onClick={(e) => {
                        e.stopPropagation();
                        if (full) {
                            onShowFullscreenImage?.(full);
                        }
                    }}
                />
            );
        }
    },
    {
        id: 'displayName',
        accessorFn: (row) => row?.user?.displayName ?? row?.$displayName ?? '',
        header: ({ column }) =>
            sortButton({
                column,
                label: t('dialog.group_member_moderation.display_name')
            }),
        size: 160,
        cell: ({ row }) => {
            const original = row.original;
            const useColors = !!(randomUserColours?.value ?? randomUserColours);
            const colorStyle = useColors ? { color: original?.user?.$userColour } : null;

            return (
                <span
                    style="cursor: pointer"
                    onClick={(e) => {
                        e.stopPropagation();
                        onShowUser?.(original?.userId);
                    }}
                >
                    <span style={colorStyle}>{original?.user?.displayName}</span>
                </span>
            );
        }
    },
    {
        id: 'roles',
        accessorFn: (row) => rolesText?.(row?.roleIds) ?? '',
        header: ({ column }) =>
            sortButton({
                column,
                label: t('dialog.group_member_moderation.roles')
            }),
        cell: ({ row }) => {
            const original = row.original;
            return <span>{rolesText?.(original?.roleIds) ?? ''}</span>;
        }
    },
    {
        accessorKey: 'managerNotes',
        header: ({ column }) =>
            sortButton({
                column,
                label: t('dialog.group_member_moderation.notes')
            }),
        cell: ({ row }) => {
            const managerNotes = row.original?.managerNotes ?? '';
            return (
                <TooltipWrapper content={managerNotes} disabled={!managerNotes}>
                    <span class="inline-block max-w-full truncate align-middle" onClick={(e) => e.stopPropagation()}>
                        {managerNotes}
                    </span>
                </TooltipWrapper>
            );
        }
    },
    {
        accessorKey: 'joinedAt',
        header: ({ column }) =>
            sortButton({
                column,
                label: t('dialog.group_member_moderation.joined_at')
            }),
        size: 170,
        cell: ({ row }) => <span>{formatDateFilter(row.original?.joinedAt, 'long')}</span>
    },
    {
        accessorKey: 'bannedAt',
        header: ({ column }) =>
            sortButton({
                column,
                label: t('dialog.group_member_moderation.banned_at')
            }),
        size: 170,
        cell: ({ row }) => <span>{formatDateFilter(row.original?.bannedAt, 'long')}</span>
    }
];
