<script setup>
    import { reactiveOmit } from '@vueuse/core';
    import { ChevronRight } from 'lucide-vue-next';
    import { ContextMenuSubTrigger, useForwardProps } from 'reka-ui';
    import { cn } from '@/lib/utils';

    const props = defineProps({
        disabled: { type: Boolean, required: false },
        textValue: { type: String, required: false },
        asChild: { type: Boolean, required: false },
        as: { type: null, required: false },
        class: { type: null, required: false },
        inset: { type: Boolean, required: false }
    });

    const delegatedProps = reactiveOmit(props, 'class');

    const forwardedProps = useForwardProps(delegatedProps);
</script>

<template>
    <ContextMenuSubTrigger
        data-slot="context-menu-sub-trigger"
        :data-inset="inset ? '' : undefined"
        v-bind="forwardedProps"
        :class="
            cn(
                'focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-pointer items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*=\'size-\'])]:size-4',
                props.class
            )
        ">
        <slot />
        <ChevronRight class="ml-auto" />
    </ContextMenuSubTrigger>
</template>
