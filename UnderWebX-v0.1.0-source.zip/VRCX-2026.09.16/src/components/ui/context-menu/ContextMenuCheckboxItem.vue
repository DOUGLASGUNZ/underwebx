<script setup>
    import { reactiveOmit } from '@vueuse/core';
    import { Check } from 'lucide-vue-next';
    import { ContextMenuCheckboxItem, ContextMenuItemIndicator, useForwardPropsEmits } from 'reka-ui';
    import { cn } from '@/lib/utils';

    const props = defineProps({
        modelValue: { type: [Boolean, String], required: false },
        disabled: { type: Boolean, required: false },
        textValue: { type: String, required: false },
        asChild: { type: Boolean, required: false },
        as: { type: null, required: false },
        class: { type: null, required: false }
    });
    const emits = defineEmits(['select', 'update:modelValue']);

    const delegatedProps = reactiveOmit(props, 'class');

    const forwarded = useForwardPropsEmits(delegatedProps, emits);
</script>

<template>
    <ContextMenuCheckboxItem
        data-slot="context-menu-checkbox-item"
        v-bind="forwarded"
        :class="
            cn(
                'focus:bg-accent focus:text-accent-foreground relative flex cursor-pointer items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*=\'size-\'])]:size-4',
                props.class
            )
        ">
        <span class="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center">
            <ContextMenuItemIndicator>
                <slot name="indicator-icon">
                    <Check class="size-4" />
                </slot>
            </ContextMenuItemIndicator>
        </span>
        <slot />
    </ContextMenuCheckboxItem>
</template>
